/**
 * 在 iframe 内嵌展示时隐藏静态页自带的顶栏，避免与 FullscreenEmbed 顶栏重复
 */
(function () {
  try {
    if (window.self !== window.top) {
      var el = document.createElement('style');
      el.setAttribute('data-ig-embed', '1');
      el.textContent = '.header{display:none!important}';
      document.head.appendChild(el);
    }
  } catch (e) { /* 忽略 */ }
})();
