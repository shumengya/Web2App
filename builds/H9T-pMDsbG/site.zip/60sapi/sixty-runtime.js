/* 由 SPA 在 iframe URL 上附加 ?sixty_base=encodeURIComponent(baseUrl)；无参数时默认萌芽节点 */
(function () {
  var fallback = 'https://60s.api.shumengya.top';
  var base = fallback;
  try {
    var q = new URLSearchParams(window.location.search).get('sixty_base');
    if (q) {
      base = decodeURIComponent(q);
    }
  } catch (e) {}
  base = String(base).replace(/\/+$/, '');
  window.__SIXTY_API_BASE__ = base || fallback;
})();
