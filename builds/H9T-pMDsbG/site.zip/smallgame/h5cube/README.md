## 汉化&修改

3D魔方，可以在浏览器中操作复原魔方，不过没有自动复原的功能。

这个项目的原码时网上搜到的，我做了含糊额和制作了docker镜像。

- 我汉化和构建docker镜像的
  - GitHub仓库 https://github.com/Firfr/h5cube
  - Gitee仓库 https://gitee.com/firfe/h5cube


欢迎关注我B站账号 [秦曱凧](https://space.bilibili.com/17547201) (读作 qín yuē zhēng)  

有需要帮忙部署这个项目的朋友,一杯奶茶,即可程远程帮你部署，需要可联系。  
微信号 `E-0_0-`  
闲鱼搜索用户 `明月人间`  
或者邮箱 `firfe163@163.com`  
如果这个项目有帮到你。欢迎start。

有其他的项目的汉化需求，欢迎提issue。或其他方式联系通知。

### 镜像

从阿里云或华为云镜像仓库拉取镜像，注意填写镜像标签，镜像仓库中没有`latest`标签

容器内部端口`5146`，可通过设置启动参数的值来指定监听端口。

```bash
swr.cn-north-4.myhuaweicloud.com/firfe/h5cube:2025.09.17
```

### docker run 命令部署

```bash
docker run -d \
--name h5cube \
--network bridge \
--restart always \
--log-opt max-size=1m \
--log-opt max-file=1 \
-p 5146:5146 \
swr.cn-north-4.myhuaweicloud.com/firfe/h5cube:2025.09.17
```
在命令最后追加`-p 端口`自定义端口

### compose 文件部署 👍推荐

```yaml
#version: '3'
name: h5cube
services:
  h5cube:
    container_name: h5cube
    image: swr.cn-north-4.myhuaweicloud.com/firfe/h5cube:2025.09.17
    network_mode: bridge
    restart: always
    logging:
      options:
        max-size: 1m
        max-file: '1'
    ports:
      - 5146:5146
    # 指定端口
    # command: ["-p", "自定义端口"] 
```

### 效果截图

| ![设置](图片/设置.jpg) | ![首页](图片/首页.jpg) |
|-|-|

