import{b as r}from"./graph-Bs4nW7sQ.js";var e=4;function a(o){return r(o,e)}export{a as c};
