import {
  STORAGE_KEY,
  PROFILES_KEY,
  ACTIVE_PROFILE_KEY,
  THEME_KEY,
  LANG_KEY,
  VIEW_KEY,
  DENSITY_KEY,
  SORT_BY_KEY,
  SORT_ORDER_KEY,
} from './constants.js'

/** @typedef {{ accountId?: string; accessKeyId?: string; secretAccessKey?: string; bucket?: string; filenameTpl?: string; filenameTplScope?: string; customDomain?: string; bucketAccess?: 'public' | 'private'; compressMode?: string; compressLevel?: string; tinifyKey?: string; uploadConcurrency?: number }} AppConfig */
/** @typedef {AppConfig & { theme?: string; lang?: string; view?: string; density?: string; sortBy?: string; sortOrder?: string }} SharePayload */
/** @typedef {{ id: string; name: string; config: AppConfig }} ConfigProfile */

class ConfigManager {
  /** @returns {AppConfig} */
  load() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '{}') || {}
    } catch {
      return /** @type {AppConfig} */ ({})
    }
  }

  /** @param {AppConfig} cfg */
  save(cfg) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg))
    const activeId = this.getActiveProfileId()
    if (activeId && this.listProfiles().some((p) => p.id === activeId)) {
      this.saveProfile(cfg, activeId)
    }
  }

  /** @returns {AppConfig} */
  get() {
    return this.load()
  }

  clear() {
    localStorage.removeItem(STORAGE_KEY)
    localStorage.removeItem(ACTIVE_PROFILE_KEY)
  }

  /* --- Multi-bucket profiles --- */

  /** @returns {ConfigProfile[]} */
  listProfiles() {
    try {
      const list = JSON.parse(localStorage.getItem(PROFILES_KEY) ?? '[]')
      return Array.isArray(list) ? list.filter((p) => p && p.id && p.config) : []
    } catch {
      return []
    }
  }

  /** @param {ConfigProfile[]} list */
  #saveProfiles(list) {
    localStorage.setItem(PROFILES_KEY, JSON.stringify(list))
  }

  /** @returns {string} */
  getActiveProfileId() {
    return localStorage.getItem(ACTIVE_PROFILE_KEY) ?? ''
  }

  /** Migrate legacy single config into a profile (no-op if profiles exist) */
  ensureMigrated() {
    if (this.listProfiles().length > 0) return
    if (!this.isValid()) return
    this.saveProfile(this.load())
  }

  /**
   * Create or update a profile and mark it active.
   * @param {AppConfig} cfg @param {string} [id] existing profile id to update @returns {string} profile id
   */
  saveProfile(cfg, id) {
    const list = this.listProfiles()
    const existing = id ? list.find((p) => p.id === id) : undefined
    if (existing) {
      existing.config = { ...cfg }
      existing.name = this.#profileName(cfg, list.filter((p) => p.id !== existing.id))
    } else {
      id = `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
      list.push({ id, name: this.#profileName(cfg, list), config: { ...cfg } })
    }
    this.#saveProfiles(list)
    localStorage.setItem(ACTIVE_PROFILE_KEY, /** @type {string} */ (id))
    return /** @type {string} */ (id)
  }

  /**
   * Switch active bucket: copy profile config into the active slot.
   * @param {string} id @returns {AppConfig | null}
   */
  switchProfile(id) {
    const profile = this.listProfiles().find((p) => p.id === id)
    if (!profile) return null
    localStorage.setItem(ACTIVE_PROFILE_KEY, id)
    this.save(profile.config)
    return profile.config
  }

  /** @param {string} id @returns {boolean} whether the deleted profile was active */
  deleteProfile(id) {
    const wasActive = this.getActiveProfileId() === id
    this.#saveProfiles(this.listProfiles().filter((p) => p.id !== id))
    if (wasActive) this.clear()
    return wasActive
  }

  /**
   * Derive a unique display name from the bucket name.
   * @param {AppConfig} cfg @param {ConfigProfile[]} others @returns {string}
   */
  #profileName(cfg, others) {
    const base = cfg.bucket || 'R2'
    const names = new Set(others.map((p) => p.name))
    if (!names.has(base)) return base
    let i = 2
    while (names.has(`${base} (${i})`)) i++
    return `${base} (${i})`
  }

  isValid() {
    const c = this.load()
    return !!(c.accountId && c.accessKeyId && c.secretAccessKey && c.bucket)
  }

  getEndpoint() {
    const c = this.load()
    return `https://${c.accountId}.r2.cloudflarestorage.com`
  }

  getBucketUrl() {
    const c = this.load()
    return `${this.getEndpoint()}/${c.bucket}`
  }

  toBase64() {
    /** @type {SharePayload} */
    const payload = {
      ...this.load(),
      theme: localStorage.getItem(THEME_KEY) || undefined,
      lang: localStorage.getItem(LANG_KEY) || undefined,
      view: localStorage.getItem(VIEW_KEY) || undefined,
      density: localStorage.getItem(DENSITY_KEY) || undefined,
      sortBy: localStorage.getItem(SORT_BY_KEY) || undefined,
      sortOrder: localStorage.getItem(SORT_ORDER_KEY) || undefined,
    }
    return btoa(unescape(encodeURIComponent(JSON.stringify(payload))))
  }

  /** @param {string} b64 @returns {boolean} */
  loadFromBase64(b64) {
    try {
      const json = decodeURIComponent(escape(atob(b64)))
      /** @type {SharePayload} */
      const payload = JSON.parse(json)
      if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return false

      const { theme, lang, view, density, sortBy, sortOrder, ...r2Config } = payload
      if (theme) localStorage.setItem(THEME_KEY, theme)
      if (lang) localStorage.setItem(LANG_KEY, lang)
      if (view) localStorage.setItem(VIEW_KEY, view)
      if (density) localStorage.setItem(DENSITY_KEY, density)
      if (sortBy) localStorage.setItem(SORT_BY_KEY, sortBy)
      if (sortOrder) localStorage.setItem(SORT_ORDER_KEY, sortOrder)

      if (Object.values(r2Config).some(Boolean)) {
        this.saveProfile(r2Config)
        this.save(r2Config)
      }
      return true
    } catch {
      /* invalid base64 or JSON */
    }
    return false
  }

  getShareUrl() {
    const b64 = this.toBase64()
    const url = new URL(window.location.href)
    url.searchParams.set('config', b64)
    url.hash = ''
    return url.toString()
  }
}

export { ConfigManager }
