#!/usr/bin/env node
/**
 * install-cli.mjs — install (or remove) a global `pi-mesh` command.
 *
 * Wraps client.mjs so you can drive pi-mesh from any terminal:
 *   pi-mesh scan
 *   pi-mesh send 192.168.1.20:41234 "hello"
 *   pi-mesh msgs 192.168.1.20:41234 25
 *
 * Usage:
 *   node install-cli.mjs              # install (idempotent, overwrites existing)
 *   node install-cli.mjs --no-add-path  # install but don't touch your shell config
 *   node install-cli.mjs uninstall    # remove
 *   node install-cli.mjs status       # show where pi-mesh is registered
 *
 * Platform handling:
 *   - Unix (Linux/macOS/Termux): symlink `~/.local/bin/pi-mesh` -> client.mjs.
 *     If `~/.local/bin` is not on PATH, appends a PATH export (idempotent) to
 *     your detected login shell config (~/.bashrc, ~/.zshrc, ~/.profile, fish).
 *   - Windows: create `%USERPROFILE%\.local\bin\pi-mesh.cmd` and add that dir to
 *     the user PATH (works in PowerShell and cmd).
 */

import { platform, homedir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { execFile } from "node:child_process";
import { mkdir, writeFile, chmod, symlink, rm, access, unlink, readFile } from "node:fs/promises";

const __dirname = dirname(fileURLToPath(import.meta.url));
const clientPath = join(__dirname, "client.mjs");
const isWin = platform() === "win32";
const binDir = join(homedir(), ".local", "bin");
const cmdName = "pi-mesh";
const installCmd = isWin ? join(binDir, `${cmdName}.cmd`) : join(binDir, cmdName);
const PATH_MARKER_BEGIN = "# >>> pi-mesh >>>";
const PATH_MARKER_END = "# <<< pi-mesh <<<";

async function exists(p) {
  try {
    await access(p);
    return true;
  } catch {
    return false;
  }
}

function isOnPath(dir) {
  const pathEnv = (process.env.PATH || "").split(/[;:]/).map((p) => p.trim());
  return pathEnv.some((p) => p === dir || p.toLowerCase() === dir.toLowerCase());
}

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { cwd: __dirname }, (err, stdout, stderr) => {
      if (err) reject(err);
      else resolve({ stdout, stderr });
    });
  });
}

// -- shell PATH config (Unix) ---------------------------------------------
function loginShellRc() {
  const shell = (process.env.SHELL || "").toLowerCase().split("/").pop();
  if (shell === "zsh") return join(homedir(), ".zshrc");
  if (shell === "fish") return join(homedir(), ".config", "fish", "config.fish");
  if (shell === "bash") return join(homedir(), ".bashrc");
  return join(homedir(), ".profile");
}

async function pathLineFor(rc) {
  if (rc.endsWith("config.fish")) {
    return `set -U fish_user_paths $HOME/.local/bin $fish_user_paths`;
  }
  return `export PATH="$HOME/.local/bin:$PATH"`;
}

async function addPathToRc(rc) {
  let content = "";
  try {
    content = await readFile(rc, "utf8");
  } catch {
    content = "";
  }
  if (content.includes(PATH_MARKER_BEGIN)) {
    console.log(`\nPATH already configured in ${rc}.`);
    return;
  }
  const line = await pathLineFor(rc);
  const block = `${PATH_MARKER_BEGIN}\n${line}\n${PATH_MARKER_END}\n`;
  await writeFile(rc, `${content.trimEnd()}\n\n${block}`, "utf8");
  console.log(`\nAppended a PATH export to ${rc} (new shells will have \`pi-mesh\` on PATH).`);
  if (!rc.endsWith("config.fish")) {
    console.log("   To use it now, run:  source " + rc + "   (or open a new terminal)");
  }
}

async function removePathFromRc(rc) {
  try {
    let content = await readFile(rc, "utf8");
    const start = content.indexOf(PATH_MARKER_BEGIN);
    const end = content.indexOf(PATH_MARKER_END);
    if (start !== -1 && end !== -1 && end > start) {
      content = content.slice(0, start) + content.slice(end + PATH_MARKER_END.length);
      await writeFile(rc, content.replace(/\n{3,}/g, "\n\n"), "utf8");
      console.log(`Removed the pi-mesh PATH block from ${rc}.`);
    }
  } catch {
    /* rc not present or readable — ignore */
  }
}

// -- install / uninstall ---------------------------------------------------
async function installUnix() {
  await mkdir(binDir, { recursive: true });
  await chmod(clientPath, 0o755);
  try {
    await rm(installCmd, { force: true });
    await symlink(clientPath, installCmd);
  } catch {
    await writeFile(installCmd, `#!/usr/bin/env sh\nexec node "${clientPath}" "$@"\n`, "utf8");
    await chmod(installCmd, 0o755);
  }
  console.log(`Installed: ${installCmd}`);
  if (!isOnPath(binDir)) {
    if (!process.argv.includes("--no-add-path")) await addPathToRc(loginShellRc());
    else console.log(`\nNOTE: "${binDir}" is not on PATH. Add it with:\n  export PATH="$HOME/.local/bin:$PATH"`);
  } else {
    console.log(`\nPATH OK — run \`${cmdName} scan\` to try it.`);
  }
}

async function installWindows() {
  await mkdir(binDir, { recursive: true });
  await writeFile(installCmd, `@echo off\r\nnode "${clientPath}" %*\r\n`, "utf8");
  console.log(`Installed: ${installCmd}`);
  if (!isOnPath(binDir)) {
    try {
      await run("powershell.exe", [
        "-NoProfile",
        "-Command",
        `[Environment]::SetEnvironmentVariable('Path', ([Environment]::GetEnvironmentVariable('Path','User') + ';${binDir}'), 'User')`,
      ]);
      console.log(`Added "${binDir}" to the user PATH (takes effect in new shells).`);
    } catch {
      console.log(`\nNOTE: add "${binDir}" to PATH manually, or run in PowerShell:\n  [Environment]::SetEnvironmentVariable('Path', "$env:Path;${binDir}", 'User')\n`);
    }
  } else {
    console.log(`PATH OK — open a new PowerShell/cmd window and run \`${cmdName} scan\`.`);
  }
}

async function uninstall() {
  await rm(installCmd, { force: true });
  console.log(`Removed: ${installCmd}`);
  if (!isWin) await removePathFromRc(loginShellRc());
  console.log(`\nOn Windows, remove "${binDir}" from PATH if you added it only for pi-mesh.`);
}

async function status() {
  const installed = await exists(installCmd);
  console.log(`command   : ${cmdName}`);
  console.log(`script    : ${clientPath}`);
  console.log(`install   : ${installCmd}`);
  console.log(`installed : ${installed ? "yes" : "no"}`);
  console.log(`on PATH   : ${installCmd} ${isOnPath(binDir) ? "(dir on PATH)" : "(dir NOT on PATH)"}`);
}

const [cmd = "install"] = process.argv.slice(2);
try {
  if (cmd === "uninstall") await uninstall();
  else if (cmd === "status") await status();
  else if (isWin) await installWindows();
  else await installUnix();
} catch (err) {
  console.error(`install-cli failed: ${err.message}`);
  process.exit(1);
}
