/**
 * pi-mesh
 *
 * Lets pi agents on the same LAN discover each other, exchange messages, and
 * read each other's latest messages. Every running pi opens a listener; peers
 * self-organize into a mesh over the network.
 *
 * How it works
 * ------------
 *  - On `session_start`, this extension starts an HTTP server bound to
 *    0.0.0.0:<random-port> (port 0 => OS picks an ephemeral port).
 *  - Peers discover each other via UDP broadcast on a fixed discovery port
 *    (env PI_MESH_DISCOVERY_PORT, default 45000). Each pi periodically announces
 *    its host:port; a `scan` probe makes discovery fast.
 *  - POST /send { text }  -> injects a message; if text starts with "/" it dispatches
 *                            a command (built-ins /compact, /name; extension commands;
 *                            /skill:; prompt templates) instead of a plain prompt.
 *                            Busy delivery defaults to steer (after current tools);
 *                            set PI_MESH_DELIVER_AS=followUp to wait until idle.
 *  - GET  /messages        -> recent messages from this pi.
 *  - GET  /peers           -> discovered peers.
 *  - GET  /                -> metadata.
 *
 * Config (priority high → low)
 *  - plugin config.json  { alias, token, peers }
 *  - PI_MESH_NAME / PI_MESH_TOKEN / PI_MESH_DISCOVERY_PORT / …
 *  - CLI flag --mesh-token
 *
 *  alias   friendly identity announced on the LAN (use instead of host:port)
 *  token   shared secret required by peers (same value on every node)
 *  peers   optional bookmarks: { "codepilot": "10.1.1.20:58004" }
 *
 * SECURITY: this bridge binds 0.0.0.0 and is reachable by anyone on the LAN.
 * A /send call injects a user message that can make the agent run tools, so
 * set token in config.json (or PI_MESH_TOKEN / --mesh-token) unless you fully trust your network.
 *
 * Commands: /mesh-status, /mesh-list, /mesh-send <alias|peer> <msg>,
 *           /mesh-alias [name], /mesh-token [value], /mesh-widget [on|off]
 * Tools:    mesh_peers, mesh_send, mesh_read
 */

import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { defineTool } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { createSocket, type Socket } from "node:dgram";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { networkInterfaces } from "node:os";

const DISCOVERY_PORT = Number(process.env.PI_MESH_DISCOVERY_PORT ?? 45000);
const ANNOUNCE_INTERVAL_MS = 5000;
const PEER_TTL_MS = 25000;
const MAX_MESSAGES = 100;
const INJECT_TTL_MS = 5 * 60 * 1000;
const HERE = dirname(fileURLToPath(import.meta.url));

interface Peer {
  name: string;
  alias?: string;
  host: string;
  port: number;
  lastSeen: number;
}

interface Msg {
  ts: number;
  role: "user" | "assistant" | "mesh";
  text: string;
}

interface MeshConfig {
  /** Friendly identity announced on the LAN; peers can connect with this instead of host:port. */
  alias: string;
  /** Shared secret required to call this pi (and used when calling peers). */
  token: string;
  /** Optional alias → host:port bookmarks (fallback when not yet discovered). */
  peers: Record<string, string>;
}

const DEFAULT_CONFIG: MeshConfig = {
  alias: "",
  token: "",
  peers: {},
};

function resolveConfigPath(): string {
  const sibling = join(HERE, "config.json");
  const parent = join(HERE, "..", "config.json");
  // Prefer plugin-root config when running from dist/index.js
  if (existsSync(parent)) return parent;
  return sibling;
}

function asPeerBookmarks(value: unknown): Record<string, string> {
  if (!value || typeof value !== "object") return {};
  const out: Record<string, string> = {};
  for (const [key, raw] of Object.entries(value as Record<string, unknown>)) {
    const alias = key.trim();
    const addr = typeof raw === "string" ? raw.trim() : "";
    if (!alias || !addr) continue;
    out[alias] = addr;
  }
  return out;
}

function mergeConfig(raw: unknown): MeshConfig {
  const obj = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  return {
    alias: typeof obj.alias === "string" ? obj.alias.trim() : "",
    token: typeof obj.token === "string" ? obj.token : "",
    peers: asPeerBookmarks(obj.peers),
  };
}

function writeConfig(config: MeshConfig, path = resolveConfigPath()): void {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, `${JSON.stringify(config, null, 2)}\n`, "utf8");
}

function loadConfig(forceWriteDefaults = false): { config: MeshConfig; path: string } {
  const path = resolveConfigPath();
  if (!existsSync(path)) {
    if (forceWriteDefaults) writeConfig(DEFAULT_CONFIG, path);
    return { config: { ...DEFAULT_CONFIG, peers: {} }, path };
  }
  try {
    const raw = JSON.parse(readFileSync(path, "utf8")) as unknown;
    return { config: mergeConfig(raw), path };
  } catch {
    return { config: { ...DEFAULT_CONFIG, peers: {} }, path };
  }
}

function parseHostPort(value: string): { host: string; port: number } | undefined {
  const trimmed = value.trim();
  const idx = trimmed.lastIndexOf(":");
  if (idx <= 0) return undefined;
  const host = trimmed.slice(0, idx).trim();
  const port = Number(trimmed.slice(idx + 1));
  if (!host || !Number.isFinite(port) || port <= 0) return undefined;
  return { host, port };
}

function peerLabel(peer: Peer): string {
  return peer.alias || peer.name || `${peer.host}:${peer.port}`;
}

function maskToken(token: string): string {
  if (!token) return "(empty)";
  if (token.length <= 4) return "****";
  return `${token.slice(0, 2)}***${token.slice(-2)}`;
}

export default function (pi: ExtensionAPI) {
  // -- state ---------------------------------------------------------------
  let server: Server | undefined;
  let udp: Socket | undefined;
  let started = false;
  let myPort = 0;
  let myHost = "127.0.0.1";
  let myName = "pi";
  let myAlias = "";
  let myToken = "";
  let configPath = resolveConfigPath();
  let announceTimer: ReturnType<typeof setInterval> | undefined;
  let uiRef: { ui: any } | undefined;
  let ctxRef: any | undefined;
  let lastPeerSig: string | null = null;
  let widgetEnabled = false; // TUI widget is opt-in; toggle via /mesh-widget

  const peers = new Map<string, Peer>();
  const messages: Msg[] = [];
  const injected: { text: string; ts: number }[] = []; // mesh messages pending to be seen by message_start
  /** alias → host:port bookmarks (mirrors config.peers, updated on discovery) */
  let peerBookmarks = new Map<string, string>();

  function refreshIdentityFromConfig(sessionName?: string) {
    const { config, path } = loadConfig(true);
    configPath = path;
    peerBookmarks = new Map(Object.entries(config.peers));

    const flagToken = (pi.getFlag("mesh-token") as string) || "";
    myToken = flagToken || process.env.PI_MESH_TOKEN || config.token || "";
    myAlias = (process.env.PI_MESH_NAME || config.alias || "").trim();
    myName = myAlias || sessionName || "pi";
  }

  function persistConfig(patch: Partial<MeshConfig>) {
    const { config, path } = loadConfig(true);
    const next: MeshConfig = {
      alias: patch.alias !== undefined ? patch.alias.trim() : config.alias,
      token: patch.token !== undefined ? patch.token : config.token,
      peers: patch.peers !== undefined ? patch.peers : config.peers,
    };
    writeConfig(next, path);
    configPath = path;
    peerBookmarks = new Map(Object.entries(next.peers));
    if (patch.alias !== undefined) {
      myAlias = next.alias;
      myName = myAlias || myName || "pi";
    }
    if (patch.token !== undefined && !process.env.PI_MESH_TOKEN && !(pi.getFlag("mesh-token") as string)) {
      myToken = next.token;
    }
    return next;
  }

  function rememberPeerBookmark(alias: string, host: string, port: number) {
    const key = alias.trim();
    if (!key) return;
    const addr = `${host}:${port}`;
    if (peerBookmarks.get(key) === addr) return;
    peerBookmarks.set(key, addr);
    const peersObj: Record<string, string> = {};
    for (const [k, v] of peerBookmarks) peersObj[k] = v;
    persistConfig({ peers: peersObj });
  }

  // -- helpers -------------------------------------------------------------
  function getOutboundIPv4(): string {
    const ifaces = networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const info of ifaces[name] ?? []) {
        if (info.family === "IPv4" && !info.internal) return info.address;
      }
    }
    return "127.0.0.1";
  }

  function extractText(content: any): string {
    if (typeof content === "string") return content;
    if (!Array.isArray(content)) return "";
    return content
      .filter((item) => item && item.type === "text" && typeof item.text === "string")
      .map((item) => item.text)
      .join("\n")
      .trim();
  }

  function pushMsg(role: Msg["role"], text: string) {
    if (!text) return;
    messages.push({ ts: Date.now(), role, text });
    if (messages.length > MAX_MESSAGES) messages.shift();
  }

  function recordInjection(text: string) {
    injected.push({ text, ts: Date.now() });
    if (injected.length > 50) injected.shift();
  }

  function announcePayload() {
    return {
      type: "pi-mesh",
      v: 1,
      name: myName,
      alias: myAlias || myName,
      host: myHost,
      port: myPort,
      pid: process.pid,
      ts: Date.now(),
    };
  }

  function sendAnnounce(payload: object) {
    // Don't advertise until the HTTP server has a real port.
    if (!udp || myPort === 0) return;
    const buf = Buffer.from(JSON.stringify(payload));
    try {
      udp.send(buf, 0, buf.length, DISCOVERY_PORT, "255.255.255.255", () => {});
    } catch {
      /* ignore */
    }
  }

  function announce() {
    sendAnnounce(announcePayload());
  }

  function prunePeers() {
    const now = Date.now();
    let changed = false;
    for (const [key, peer] of peers) {
      if (now - peer.lastSeen > PEER_TTL_MS) {
        peers.delete(key);
        changed = true;
      }
    }
    if (changed) refreshPeersWidget();
  }

  // -- widget refresh ------------------------------------------------------
  function peerSignature(): string {
    return [...peers.keys()].sort().join(",");
  }

  function setPeersWidget() {
    if (!uiRef) return;
    if (!widgetEnabled) {
      // Clears the widget if it's currently shown.
      uiRef.ui.setWidget("mesh", undefined);
      return;
    }
    uiRef.ui.setWidget("mesh", [
      `pi-mesh: ${myAlias || myName} @ ${myHost}:${myPort} (udp:${DISCOVERY_PORT})`,
      `Peers: ${peers.size}`,
      ...[...peers.values()].map((p) => `  ${peerLabel(p)} @ ${p.host}:${p.port}`),
    ]);
  }

  function refreshPeersWidget() {
    const sig = peerSignature();
    if (sig === lastPeerSig) return;
    lastPeerSig = sig;
    setPeersWidget();
  }

  // -- discovery -----------------------------------------------------------
  /**
   * SO_REUSEPORT is Linux/FreeBSD only. On Windows, `reusePort: true` makes
   * bind() fail with ENOTSUP, so discovery never starts and peers stay at 0.
   * `reuseAddr` alone is enough for same-host multi-listen + broadcast fan-out.
   */
  function discoverySocketOptions(reusePort: boolean): {
    type: "udp4";
    reuseAddr: boolean;
    reusePort?: boolean;
  } {
    return reusePort
      ? { type: "udp4", reuseAddr: true, reusePort: true }
      : { type: "udp4", reuseAddr: true };
  }

  function platformWantsReusePort(): boolean {
    return process.platform === "linux" || process.platform === "freebsd";
  }

  function startDiscovery(reusePort = platformWantsReusePort()) {
    try {
      udp = createSocket(discoverySocketOptions(reusePort));
      udp.on("message", (data, rinfo) => {
        let a: any;
        try {
          a = JSON.parse(data.toString("utf8"));
        } catch {
          return;
        }
        if (!a || typeof a !== "object") return;

        // Someone scanning: reply immediately with our announce so discovery is fast.
        if (a.type === "pi-mesh-probe") {
          if (myPort === 0) return;
          const buf = Buffer.from(JSON.stringify(announcePayload()));
          try {
            udp!.send(buf, 0, buf.length, rinfo.port, rinfo.address, () => {});
          } catch {
            /* ignore */
          }
          return;
        }

        if (a.type !== "pi-mesh" || !a.host || !a.port) return;
        // Ignore our own announcement (another socket on the same host may echo it back).
        if (a.pid === process.pid && a.host === myHost && a.port === myPort) return;

        const alias = typeof a.alias === "string" && a.alias.trim() ? a.alias.trim() : undefined;
        const name = typeof a.name === "string" && a.name.trim() ? a.name.trim() : alias || "pi";
        peers.set(`${a.host}:${a.port}`, {
          name,
          alias,
          host: a.host,
          port: a.port,
          lastSeen: Date.now(),
        });
        if (alias) rememberPeerBookmark(alias, a.host, a.port);
        refreshPeersWidget();
      });

      udp.on("error", (err) => {
        const code = (err as NodeJS.ErrnoException).code;
        // Windows (and some other hosts): fall back without SO_REUSEPORT.
        if (reusePort && (code === "ENOTSUP" || code === "EOPNOTSUPP")) {
          try {
            udp?.close();
          } catch {
            /* ignore */
          }
          udp = undefined;
          console.warn(`[pi-mesh] reusePort unsupported (${code}); retrying with reuseAddr only`);
          startDiscovery(false);
          return;
        }
        if (!started) return;
        console.error(`[pi-mesh] udp error: ${err.message}`);
      });

      udp.bind(DISCOVERY_PORT, "0.0.0.0", () => {
        try {
          udp!.setBroadcast(true);
        } catch {
          /* ignore */
        }
        announce();
        announceTimer = setInterval(announce, ANNOUNCE_INTERVAL_MS);
        setInterval(prunePeers, 10_000);
      });
    } catch (err) {
      if (reusePort) {
        console.warn(
          `[pi-mesh] discovery socket create failed with reusePort; retrying without: ${(err as Error).message}`,
        );
        startDiscovery(false);
        return;
      }
      console.error(`[pi-mesh] discovery unavailable: ${(err as Error).message}`);
    }
  }

  // -- http server ---------------------------------------------------------
  function corsHeaders() {
    return {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,POST,OPTIONS",
      "access-control-allow-headers": "content-type, authorization",
      "access-control-max-age": "86400",
    };
  }

  function sendJson(res: ServerResponse, obj: unknown, status = 200) {
    const body = JSON.stringify(obj);
    res.writeHead(status, {
      "content-type": "application/json; charset=utf-8",
      ...corsHeaders(),
    });
    res.end(body);
  }

  function readBody(req: IncomingMessage): Promise<string> {
    return new Promise((resolve, reject) => {
      let data = "";
      req.on("data", (chunk) => {
        data += chunk;
        if (data.length > 1_000_000) reject(new Error("body too large"));
      });
      req.on("end", () => resolve(data));
      req.on("error", reject);
    });
  }

  function clampInt(value: string | null, fallback: number, max: number): number {
    const n = Number(value ?? fallback);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(Math.max(1, Math.floor(n)), max);
  }

  function isAuthorized(req: IncomingMessage, url: URL): boolean {
    if (!myToken) return true;
    const bearer = (req.headers.authorization ?? "").replace(/^Bearer\s+/i, "");
    return bearer === myToken || url.searchParams.get("token") === myToken;
  }

  /**
   * Execute built-in slash commands that pi's TUI normally handles.
   * sendUserMessage() can only dispatch EXTENSION commands (+ skills/templates),
   * never built-ins like /compact. Return handled=false so unrecognized input
   * falls through to sendUserMessage.
   */
  function execBuiltinCommand(text: string): { handled: boolean; response: string } {
    // /compact [custom instructions]
    if (text === "/compact" || text.startsWith("/compact ")) {
      const customInstructions = text === "/compact" ? undefined : text.slice(9).trim() || undefined;
      if (!ctxRef?.compact) return { handled: false, response: "" };
      ctxRef.compact({ customInstructions });
      return {
        handled: true,
        response: customInstructions ? "compaction triggered with custom instructions" : "compaction triggered",
      };
    }
    // /name <name>
    if (text === "/name" || text.startsWith("/name ")) {
      const name = text.slice(6).trim();
      if (!name) return { handled: true, response: "usage: /name <name>" };
      pi.setSessionName(name);
      return { handled: true, response: `session renamed to "${name}"` };
    }
    return { handled: false, response: "" };
  }

  function handleRequest(req: IncomingMessage, res: ServerResponse) {
    const url = new URL(req.url ?? "/", "http://localhost");
    const path = url.pathname;

    if (req.method === "OPTIONS") {
      res.writeHead(204, corsHeaders());
      res.end();
      return;
    }

    if (!isAuthorized(req, url)) {
      sendJson(res, { ok: false, error: "unauthorized: set token in config.json / PI_MESH_TOKEN / --mesh-token" }, 401);
      return;
    }

    if (req.method === "GET" && (path === "/" || path === "/info")) {
      sendJson(res, {
        name: myName,
        alias: myAlias || myName,
        host: myHost,
        port: myPort,
        pid: process.pid,
        discoveryPort: DISCOVERY_PORT,
        peers: [...peers.values()],
      });
      return;
    }

    if (req.method === "GET" && path === "/peers") {
      sendJson(res, [...peers.values()]);
      return;
    }

    if (req.method === "GET" && path === "/messages") {
      const limit = clampInt(url.searchParams.get("limit"), 20, MAX_MESSAGES);
      sendJson(res, messages.slice(-limit));
      return;
    }

    if (req.method === "POST" && path === "/send") {
      readBody(req)
        .then((body) => {
          let text = "";
          try {
            const parsed = JSON.parse(body);
            text = typeof parsed?.text === "string" ? parsed.text : "";
          } catch {
            text = body.trim();
          }
          if (!text) return sendJson(res, { ok: false, error: "no text" }, 400);

          // Built-in slash commands (e.g. /compact) are handled by the TUI layer,
          // not by sendUserMessage. Route the supported ones here; everything else
          // falls through to sendUserMessage with expandPromptTemplates so
          // extension commands (/mesh-*), /skill:, and /template still work.
          if (text.startsWith("/")) {
            const cmd = execBuiltinCommand(text);
            if (cmd.handled) {
              recordInjection(text);
              sendJson(res, { ok: true, text, handled: true, response: cmd.response });
              return;
            }
          }

          try {
            // Prefer steer: inject after the current tool batch, before the next
            // LLM call. followUp only drains when the agent fully stops (no more
            // tools), so peer replies pile up as「后续」during long tool loops
            // (mesh_read / sleep / …) and the busy agent never "receives" them.
            // Override with PI_MESH_DELIVER_AS=followUp|steer if needed.
            const deliverAs =
              process.env.PI_MESH_DELIVER_AS === "followUp" ? "followUp" : "steer";
            pi.sendUserMessage(text, { deliverAs });
          } catch (err) {
            return sendJson(res, { ok: false, error: (err as Error).message }, 500);
          }

          recordInjection(text);
          sendJson(res, { ok: true, text });
        })
        .catch((err) => sendJson(res, { ok: false, error: (err as Error).message }, 400));
      return;
    }

    sendJson(res, { ok: false, error: "not found" }, 404);
  }

  function startServer(): Promise<number> {
    return new Promise((resolve) => {
      server = createServer(handleRequest);
      server.on("error", (err) => {
        if (!started) return;
        console.error(`[pi-mesh] http error: ${(err as Error).message}`);
        resolve(0);
      });
      server.listen(0, "0.0.0.0", () => {
        const addr = server!.address();
        const p = addr && typeof addr === "object" ? addr.port : 0;
        myPort = p;
        resolve(p);
      });
    });
  }

  // -- networking to other pis --------------------------------------------
  async function httpPeer(peer: Peer, path: string, init?: RequestInit): Promise<any> {
    const target = `http://${peer.host}:${peer.port}${path}`;
    const headers = { ...(init?.headers ?? {}) } as Record<string, string>;
    if (myToken) headers.authorization = `Bearer ${myToken}`;
    const res = await fetch(target, { ...init, headers });
    return res.json();
  }

  function resolvePeer(selector: string): Peer | undefined {
    const sel = selector.trim();
    if (!sel) return undefined;
    const lower = sel.toLowerCase();
    const parsed = parseHostPort(sel);

    // 1) exact host:port
    if (parsed) {
      const live = peers.get(`${parsed.host}:${parsed.port}`);
      if (live) return live;
    }

    // 2) live peers by alias / name / host (exact then prefix)
    const list = [...peers.values()];
    const exactAlias = list.find((p) => p.alias && p.alias.toLowerCase() === lower);
    if (exactAlias) return exactAlias;
    const exactName = list.find((p) => p.name.toLowerCase() === lower);
    if (exactName) return exactName;
    const exactHost = list.find((p) => p.host === sel);
    if (exactHost) return exactHost;
    const prefixAlias = list.find((p) => p.alias && p.alias.toLowerCase().startsWith(lower));
    if (prefixAlias) return prefixAlias;
    const prefixName = list.find((p) => p.name.toLowerCase().startsWith(lower));
    if (prefixName) return prefixName;

    // 3) config bookmark by alias (last known host:port)
    for (const [alias, addr] of peerBookmarks) {
      if (alias.toLowerCase() === lower || alias.toLowerCase().startsWith(lower)) {
        const hp = parseHostPort(addr);
        if (hp) {
          return {
            name: alias,
            alias,
            host: hp.host,
            port: hp.port,
            lastSeen: Date.now(),
          };
        }
      }
    }

    // 4) explicit host:port even if not discovered yet
    if (parsed) {
      return { name: parsed.host, host: parsed.host, port: parsed.port, lastSeen: Date.now() };
    }
    return undefined;
  }

  async function sendToPeer(peer: Peer, text: string) {
    return httpPeer(peer, "/send", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text }),
    });
  }

  async function readPeerMessages(peer: Peer, limit = 20) {
    const result = await httpPeer(peer, `/messages?limit=${encodeURIComponent(limit)}`);
    return Array.isArray(result) ? result : [];
  }

  // -- session lifecycle ---------------------------------------------------
  pi.registerFlag("mesh-token", {
    description: "Shared secret required by pi-mesh (default: config.json token / PI_MESH_TOKEN)",
    type: "string",
    default: process.env.PI_MESH_TOKEN ?? "",
  });

  pi.on("session_start", async (_event, ctx) => {
    if (process.env.PI_MESH_DISABLE) return;
    if (started) return;
    started = true;

    // Default = off. Set PI_MESH_WIDGET=1 to start with the widget pinned on.
    widgetEnabled = process.env.PI_MESH_WIDGET === "1";

    refreshIdentityFromConfig(ctx.sessionManager.getSessionName() ?? undefined);
    myHost = getOutboundIPv4();

    const portPromise = startServer();
    startDiscovery();
    myPort = await portPromise;
    const who = myAlias || myName;
    const addr = `${myHost}:${myPort}`;

    ctx.ui.notify(
      `pi-mesh listening as ${who} @ ${addr} (discovery udp:${DISCOVERY_PORT})`,
      "info",
    );
    uiRef = { ui: ctx.ui };
    ctxRef = ctx;
    // The TUI widget is opt-in: show it only when the user runs /mesh-widget on.
    setPeersWidget(); // clears it (widgetEnabled === false by default)
  });

  pi.on("session_shutdown", () => {
    started = false;
    if (announceTimer) clearInterval(announceTimer);
    if (udp) {
      try {
        udp.close();
      } catch {
        /* ignore */
      }
    }
    if (server) {
      try {
        server.close();
      } catch {
        /* ignore */
      }
    }
    server = undefined;
    udp = undefined;
    peers.clear();
  });

  // Track recent messages for /messages.
  pi.on("message_start", async (event) => {
    if (event.message.role !== "user") return;
    const text = extractText(event.message.content);
    if (!text) return;

    const now = Date.now();
    let role: Msg["role"] = "user";
    const idx = injected.findIndex((i) => i.text === text && now - i.ts < INJECT_TTL_MS);
    if (idx >= 0) {
      role = "mesh";
      injected.splice(idx, 1);
    }
    pushMsg(role, text);
  });

  pi.on("message_end", async (event) => {
    if (event.message.role !== "assistant") return;
    pushMsg("assistant", extractText(event.message.content));
  });

  // -- commands ------------------------------------------------------------
  pi.registerCommand("mesh-status", {
    description: "Show pi-mesh status and discovered peers",
    handler: async (_args, ctx) => {
      if (!started) {
        ctx.ui.notify("pi-mesh is not running (disabled or no session)", "warning");
        return;
      }
      const who = myAlias || myName;
      ctx.ui.notify(
        `pi-mesh: ${who} @ ${myHost}:${myPort} | peers: ${peers.size} | token: ${maskToken(myToken)}`,
        "info",
      );
      refreshPeersWidget();
    },
  });

  pi.registerCommand("mesh-list", {
    description: "List discovered pi-mesh peers (by alias when available)",
    handler: async (_args, ctx) => {
      const list = [...peers.values()];
      if (list.length === 0) {
        const bookmarks = [...peerBookmarks.entries()];
        if (bookmarks.length === 0) {
          ctx.ui.notify("No peers discovered yet", "info");
          return;
        }
        ctx.ui.notify(
          `No live peers. Bookmarks: ${bookmarks.map(([a, addr]) => `${a}=${addr}`).join(", ")}`,
          "info",
        );
        return;
      }
      ctx.ui.notify(
        `Found ${list.length} peer(s): ${list.map((p) => `${peerLabel(p)} (${p.host}:${p.port})`).join(", ")}`,
        "info",
      );
      refreshPeersWidget();
    },
  });

  pi.registerCommand("mesh-alias", {
    description: "Show or set this pi's mesh alias (persisted in config.json). Usage: /mesh-alias [name]",
    handler: async (args, ctx) => {
      const next = args.trim();
      if (!next) {
        ctx.ui.notify(
          `alias: ${myAlias || "(empty)"} | name: ${myName} | config: ${configPath}`,
          "info",
        );
        return;
      }
      persistConfig({ alias: next });
      announce();
      ctx.ui.notify(`pi-mesh alias set to「${next}」(saved to config.json)`, "info");
      lastPeerSig = null;
      setPeersWidget();
    },
  });

  pi.registerCommand("mesh-token", {
    description: "Show or set the shared mesh token (persisted in config.json). Usage: /mesh-token [value]",
    handler: async (args, ctx) => {
      const next = args.trim();
      if (!next) {
        ctx.ui.notify(`token: ${maskToken(myToken)} | config: ${configPath}`, "info");
        return;
      }
      if (next === "clear" || next === "off" || next === "-") {
        persistConfig({ token: "" });
        myToken = process.env.PI_MESH_TOKEN || (pi.getFlag("mesh-token") as string) || "";
        ctx.ui.notify("pi-mesh token cleared from config.json", "info");
        return;
      }
      persistConfig({ token: next });
      if (!process.env.PI_MESH_TOKEN && !(pi.getFlag("mesh-token") as string)) {
        myToken = next;
      }
      ctx.ui.notify(`pi-mesh token updated (${maskToken(next)})`, "info");
    },
  });

  pi.registerCommand("mesh-widget", {
    description: "Toggle the persistent pi-mesh TUI widget (off by default). Usage: /mesh-widget [on|off]",
    handler: async (args, ctx) => {
      const arg = args.trim().toLowerCase();
      if (arg === "on") widgetEnabled = true;
      else if (arg === "off") widgetEnabled = false;
      else widgetEnabled = !widgetEnabled;
      lastPeerSig = null; // force a redraw (or clear) right now
      setPeersWidget();
      ctx.ui.notify(`pi-mesh widget ${widgetEnabled ? "shown" : "hidden"}`, "info");
    },
  });

  pi.registerCommand("mesh-send", {
    description: "Send a message to a peer by alias / name / host[:port]. Usage: /mesh-send <alias|peer> <message>",
    handler: async (args, ctx) => {
      const trimmed = args.trim();
      if (!trimmed) {
        ctx.ui.notify("Usage: /mesh-send <alias|peer-name|host[:port]> <message>", "warning");
        return;
      }
      const [selector, ...rest] = trimmed.split(/\s+/);
      const text = rest.join(" ").trim();
      if (!text) {
        ctx.ui.notify("No message text provided", "warning");
        return;
      }
      const peer = resolvePeer(selector);
      if (!peer) {
        ctx.ui.notify(`Unknown peer: ${selector}. Use /mesh-list.`, "error");
        return;
      }
      try {
        const result = await sendToPeer(peer, text);
        if (result?.ok) {
          ctx.ui.notify(`Sent to ${peerLabel(peer)} (${peer.host}:${peer.port})`, "info");
        } else {
          ctx.ui.notify(`Peer ${peerLabel(peer)} did not accept: ${result?.error ?? "unknown"}`, "warning");
        }
      } catch (err) {
        ctx.ui.notify(`Failed to reach ${peerLabel(peer)}: ${(err as Error).message}`, "error");
      }
    },
  });

  // -- LLM tools -----------------------------------------------------------
  pi.registerTool(
    defineTool({
      name: "mesh_peers",
      label: "Mesh Peers",
      description:
        "List discovered pi instances on the local network (prefer connecting by alias).",
      parameters: Type.Object({}),
      async execute() {
        const list = [...peers.values()];
        const bookmarks = [...peerBookmarks.entries()];
        if (list.length === 0 && bookmarks.length === 0) {
          return {
            content: [{ type: "text", text: "No peers discovered." }],
            details: { peers: list, bookmarks: {} },
          };
        }
        const liveLines = list.map(
          (p) => `${peerLabel(p)} @ ${p.host}:${p.port}${p.alias ? ` (alias: ${p.alias})` : ""}`,
        );
        const bookLines =
          bookmarks.length === 0
            ? []
            : [
                "Bookmarks (config.json peers):",
                ...bookmarks.map(([alias, addr]) => `  ${alias} → ${addr}`),
              ];
        return {
          content: [
            {
              type: "text",
              text: [...liveLines, ...bookLines].join("\n") || "No peers discovered.",
            },
          ],
          details: {
            peers: list,
            bookmarks: Object.fromEntries(bookmarks),
          },
        };
      },
    }),
  );

  pi.registerTool(
    defineTool({
      name: "mesh_send",
      label: "Mesh Send",
      description:
        "Send a message to another pi instance by alias (preferred), name, or host:port. " +
        "If message starts with / it is dispatched as a command (/compact, /name, extension commands, /skill:).",
      parameters: Type.Object({
        peer: Type.String({
          description: "Peer alias (preferred), name, host, or host:port of the target pi.",
        }),
        message: Type.String({ description: "Message text, or a /command to dispatch on the target." }),
      }),
      async execute(_toolCallId, params) {
        const peer = resolvePeer(params.peer);
        if (!peer) {
          return {
            content: [{ type: "text", text: `No peer matching "${params.peer}". Use mesh_peers first.` }],
            details: { ok: false },
          };
        }
        try {
          const result = await sendToPeer(peer, params.message);
          return {
            content: [
              {
                type: "text",
                text: result?.ok
                  ? `Sent to ${peerLabel(peer)} (${peer.host}:${peer.port}).`
                  : `Peer ${peerLabel(peer)} rejected: ${result?.error ?? "unknown"}`,
              },
            ],
            details: { ok: !!result?.ok, peer },
          };
        } catch (err) {
          return {
            content: [{ type: "text", text: `Failed to reach ${peerLabel(peer)}: ${(err as Error).message}` }],
            details: { ok: false, peer },
          };
        }
      },
    }),
  );

  pi.registerTool(
    defineTool({
      name: "mesh_read",
      label: "Mesh Read",
      description: "Read the latest messages from another pi instance (by alias / name / host:port).",
      parameters: Type.Object({
        peer: Type.String({
          description: "Peer alias (preferred), name, host, or host:port of the target pi.",
        }),
        limit: Type.Optional(
          Type.Integer({
            description: "Number of latest messages to return (default 20, max 100).",
            minimum: 1,
            maximum: 100,
          }),
        ),
      }),
      async execute(_toolCallId, params) {
        const peer = resolvePeer(params.peer);
        if (!peer) {
          return {
            content: [{ type: "text", text: `No peer matching "${params.peer}". Use mesh_peers first.` }],
            details: { ok: false },
          };
        }
        try {
          const msgs = await readPeerMessages(peer, params.limit ?? 20);
          const text =
            msgs.length === 0
              ? `No messages from ${peerLabel(peer)} (${peer.host}:${peer.port}) yet.`
              : `Latest messages from ${peerLabel(peer)} (${peer.host}:${peer.port}):\n` +
                msgs.map((m: any) => `[${new Date(m.ts).toISOString()}] ${m.role}: ${m.text}`).join("\n");
          return {
            content: [{ type: "text", text }],
            details: { ok: true, peer, messages: msgs },
          };
        } catch (err) {
          return {
            content: [{ type: "text", text: `Failed to read ${peerLabel(peer)}: ${(err as Error).message}` }],
            details: { ok: false, peer },
          };
        }
      },
    }),
  );
}
